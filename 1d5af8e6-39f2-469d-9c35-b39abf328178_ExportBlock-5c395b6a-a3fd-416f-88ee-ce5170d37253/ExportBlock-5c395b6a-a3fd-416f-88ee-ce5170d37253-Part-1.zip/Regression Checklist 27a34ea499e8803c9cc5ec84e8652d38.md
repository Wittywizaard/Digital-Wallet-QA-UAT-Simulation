# Regression Checklist

### 📌 What is a **Regression Checklist?**

- Imagine you build a new feature (like **Refund**) in your FinTech app.
- You need to check that **old features** (Login, Add Money, Pay Merchant, History) still work after adding the new one.
- This checklist is just a **list of old features you will quickly re-test** whenever you add something new.

Think of it like when you fix one LEGO piece in your tower — you must check the whole tower doesn’t fall apart.

---

### 📌 How are we going to do this:

1. **Make a simple Excel sheet** 
    
    Columns can be:
    
    | Test ID | Area | Scenario | Expected Result | Status |
    
2. **List old + new features to re-check**.

Example:

| RG-01 | Login | Login with valid credentials | User logs in successfully | Pass |

| RG-02 | Add Money | Add ₹500 to wallet | Balance increases correctly | Pass |

1. **Run these tests after each release**:
    - After Sprint 1 (v1.0 → only core features).
    - After Sprint 2 (v1.1 → Refund + Notifications).
    
    **Mark status**: “Pass” or “Fail”.