# Digital Wallet – QA & UAT Simulation

End date: 09/26/2025
Status: In progress

**Digital Wallet Simulation (FinTech QA & Release Management Project)**

- Simulated a wallet app workflow (*registration → add money → pay merchant → refund*).
- Authored 7 **user stories** in Jira and organized them into **2 sprints** with acceptance criteria.
- Designed **manual test cases** (positive & negative), maintained a **defect log**, and built a **regression checklist**.
- Conducted a mock **UAT cycle with stakeholder feedback** to simulate release sign-off.
- Demonstrated end-to-end **release management, QA, and UAT practices** aligned with FinTech product lifecycles.

## **Workflow Diagram**

![diagram-export-9-26-2025-11_02_06-AM.png](diagram-export-9-26-2025-11_02_06-AM.png)

## **User Stories (Jira)**

[User Stories (JIRA)](User%20Stories%20(JIRA)%2027a34ea499e8802fad39fa8efa4d5c0e.md)

![Screenshot 2025-09-26 115140.png](Screenshot_2025-09-26_115140.png)

![Screenshot 2025-09-26 124101.png](Screenshot_2025-09-26_124101.png)

## Release Planning

- **Sprint 1 (Core)**: User Registration, Add Money, Pay Merchant.
- **Sprint 2 (Enhancements)**: Transaction History, Refunds, Notifications.
- Release Notes:
    - **v1.0** → Core wallet functions.
    - **v1.1** → Enhancements + fixes.

![Screenshot 2025-09-26 124717.png](Screenshot_2025-09-26_124717.png)

![Screenshot 2025-09-26 124803.png](Screenshot_2025-09-26_124803.png)

## **Test Cases**

Format:

| Test Case ID | Feature | Steps | Expected Result | Actual Result | Status |

[03_TestCases.xlsx](03_TestCases.xlsx)

## Defect Log

Format:

| Defect ID | Feature | Description | Severity | Status |

[04_DefectLog.xlsx](04_DefectLog.xlsx)

## Regression Checklist

Examples:

- Verify login works after adding refund module.
- Verify add money still updates balance correctly.
- Verify history reflects payments + refunds.

[**Regression Checklist**](Regression%20Checklist%2027a34ea499e8803c9cc5ec84e8652d38.md)

[Regression_Checklist.xlsx](Regression_Checklist.xlsx)

## UAT Report

[07_UAT_Report.docx](07_UAT_Report.docx)